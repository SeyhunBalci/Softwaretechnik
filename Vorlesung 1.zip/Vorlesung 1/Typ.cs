﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vorlesung_1
{
    class Typ
    {
        public string name = "";
        public int geld = 50;

        public Typ(int geld, String name)
        {
            this.name = name;
            this.geld = geld;
        }

        public String GeldVerleihen(int betrag)
        {
            String transferResult;
            if (betrag <= geld && betrag > 0)
            {
                geld -= betrag;
                transferResult = "Success";
            }
            else
            {
                transferResult = "Ich habe nicht genug, um dir " + betrag +
                  "€ zu geben, sagt " + name;
            }
            return transferResult;
        }

        public String GeldEmpfangen(int betrag)
        {
            String transferResult;

            if (betrag > 0)
            {
                geld += betrag;
                transferResult = "Success";
            }
            else
            {
                transferResult = betrag + " ist kein Betrag den ich" +
                      " akzeptiere, sagt " + name;
            }
            return transferResult;
        }
    }

}
