﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Vorlesung_1
{

    public partial class MainWindow : Window
    {
        Typ tom, tim, bank;
        String success = "";
        int betrag = 5;
        public MainWindow()
        {
            InitializeComponent();
            tom = new Typ(50, "Tom");
            tim = new Typ(50, "Tim");
            bank = new Typ(50, "Bank");

            FormularAktualisieren();
        }

    public void FormularAktualisieren()
    {
            TimLabel.Content = tim.name + " hat " + tim.geld + " €";
            TomLabel.Content = tom.name + " hat " + tom.geld + " €";
            dieBankLabel.Content = "Die Bank hat " + bank.geld + " €";
            TransferResultsLabel.Content = success;
    }

        private void gibtButton_Click(object sender, RoutedEventArgs e)
    {
               if (TimRadioButton.IsChecked == true)
            {
                switch (ComboBox.SelectedIndex)
                {
                    case 0: success = "Tim kann mit sich selber nicht handeln"; break;
                    case 1: success = tim.GeldVerleihen(betrag);
                        if (success == "Success") tom.GeldEmpfangen(betrag); break;
                    case 2: success = tim.GeldVerleihen(betrag); 
                        if (success == "Success") bank.GeldEmpfangen(betrag); break;
                    default: break;
                }
            }
            else if (TomRadioButton.IsChecked == true)
            {
                switch (ComboBox.SelectedIndex)
                {
                    case 0: success = tom.GeldVerleihen(betrag); 
                        if (success == "Success") tim.GeldEmpfangen(betrag); break;
                    case 1: success = "Tom kann mit sich selber nicht handeln"; break;
                    case 2: success = tom.GeldVerleihen(betrag); 
                        if (success == "Success") bank.GeldEmpfangen(betrag); break;
                    default: break;
                }
            }
            else if (dieBankRadioButton.IsChecked == true)
            {
                switch (ComboBox.SelectedIndex)
                {
                    case 0: success = bank.GeldVerleihen(betrag); 
                        if (success == "Success") tim.GeldEmpfangen(betrag); break;
                    case 1: success = bank.GeldVerleihen(betrag); 
                        if (success == "Success") tom.GeldEmpfangen(betrag); break;
                    case 2: success = "Die Bank kann mit sich selber nicht handeln"; break;
                    default: break;
                }
            }
            FormularAktualisieren();

  
    }

    private void bekommtButton_Click(object sender, RoutedEventArgs e)
    {
            if (TimRadioButton.IsChecked == true)
            {
                switch (ComboBox.SelectedIndex)
                {
                    case 0: success = "Tim kann mit sich selber nicht handeln"; break;
                    case 1: success = tom.GeldVerleihen(betrag); 
                        if (success == "Success") tim.GeldEmpfangen(betrag); break;
                    case 2: success = bank.GeldVerleihen(betrag); 
                        if (success == "Success") tim.GeldEmpfangen(betrag); break;
                    default: break;
                }
            }
            else if (TomRadioButton.IsChecked == true)
            {
                switch (ComboBox.SelectedIndex)
                {
                    case 0: success = tim.GeldVerleihen(betrag); 
                        if (success == "Success") tom.GeldEmpfangen(betrag); break;
                    case 1: success = "Tom kann mit sich selber nicht handeln"; break;
                    case 2: success = bank.GeldVerleihen(betrag); 
                        if (success == "Success") tom.GeldEmpfangen(betrag); break;
                    default: break;
                }
            }
            else if (dieBankRadioButton.IsChecked == true)
            {
                switch (ComboBox.SelectedIndex)
                {
                    case 0: success = tim.GeldVerleihen(betrag); 
                        if (success == "Success") bank.GeldEmpfangen(betrag); break;
                    case 1: success = tom.GeldVerleihen(betrag); 
                        if (success == "Success") bank.GeldEmpfangen(betrag); break;
                    case 2: success = "Die Bank kann mit sich selber nicht handeln"; break;
                    default: break;
                }
            }
            FormularAktualisieren();
    }  
      
    }
}
